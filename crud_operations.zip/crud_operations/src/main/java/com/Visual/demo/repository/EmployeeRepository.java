package com.Visual.demo.repository;

import com.Visual.demo.model.Employee;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee , Long>
{
}
